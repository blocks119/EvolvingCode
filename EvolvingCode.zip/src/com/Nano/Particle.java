package com.Nano;

import java.util.ArrayList;

public class Particle {
    double InternalEnergy; // Each particle needs to conserve energy, when two atoms bond they should each gain internal energy, when two are slowed down relative to each other they should gain internal energy , if the internal energy of an atom is high enough to break it's current bonds it should look for any more suitable atoms nearby to bond to and if one is available bond to that instead
    //double

    double Xpos;
    double Ypos;
    double Xvelocity;
    double Yvelocity;
    double newXpos;
    double newYpos;
    double newXvelocity;
    double newYvelocity;
    ArrayList<Particle> covalentBonds = new ArrayList<Particle>(); // the bonded particle should have this particle in it's covalent bonds list
    float OuterRadius = 0.2f; // the distance of the outer electron shell , the stable length of a covalent bond is this outer radius plus the other particles outer radius
    int bondQuantity;
    float mass = 0;
    float charge = 0;

    ArrayList<Particle> bonded;
    Particle(float xpos, float ypos){
        Xpos = xpos;
        Ypos = ypos;
        Xvelocity=0;
        Yvelocity=0;
    }
    Particle(float xpos, float ypos ,float xvel, float yvel){
        Xpos = xpos;
        Ypos = ypos;
        Xvelocity=xvel;
        Yvelocity=yvel;
    }
}
