package com.Nano;

public class Organism {
    float Xpos;
    float Ypos;
    float Xvelocity;
    float Yvelocity;

    Organism(float xpos,float ypos){
        Xpos = xpos;
        Ypos = ypos;
        Xvelocity=0f;
        Yvelocity=0f;
    }
}
