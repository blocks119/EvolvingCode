package com.Nano;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.ArrayList;
import javax.swing.*;

public class Atoms extends JPanel implements MouseMotionListener{
    public static void main(String[] args) {
        new Atoms();
    }
    BufferedImage img;

    static float bondBreakMultiplier=15;
    static float bondFormMultiplier=12;
    final static int windowWidth = 1920;
    final static int windowHeight = 1080;
    final static int gridWidth = 30;
    final static int gridHeight = 30;
    final static int gridTileSize = 5; // size in units of each tile in the grid
    static ArrayList<Particle>[][] Particles; // 2d grid of areas, each containing a list of particles in that area
    static int ParticleQuantity = 800;
    static int scale = 5;
    static int displayiterator = 0;
    static int iteratortime = 2;
    static float MaxInitialVelocity = 1f;
    static float MinInitialVelocity = 0;
    static float dragfactor = -.01f;
    static float forceRadius = 2f;
    static float speed = 0.00003f;
    static int numberoftypes = 5;
    static double[] typeabundance = {4,.2,1,1};

    Atoms(){

        InitializeWindow();

        Start();
        while (true) {
            Update();
        }
    }
    public void InitializeWindow(){
        img = new BufferedImage(windowWidth, windowHeight,
                BufferedImage.TYPE_INT_ARGB_PRE);
        setPreferredSize(new Dimension(windowWidth, windowHeight));


        JFrame frame = new JFrame();
        this.addMouseMotionListener(this); // INSTEAD OF THE FRAME
        frame.add(this);
        //frame.setSize(width, height);  DO INSTEAD...
        frame.pack();
        //frame.setEnabled(true);  REDUNDANT
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  // good call!
    }

    public void Start(){
        Particles = new ArrayList[gridWidth][gridHeight];
        for (int x = 0; x< gridWidth; x++) {
            for (int y = 0; y< gridHeight; y++) {
                Particles[x][y] = new ArrayList<Particle>();
            }
        }
        double typeabundanceTotal = 0;
        for(double i1 : typeabundance){
            typeabundanceTotal = typeabundanceTotal+i1;
        }
        for(int i = 0;i<ParticleQuantity;i++) {
            float xpos = (float) Math.random() * gridWidth * gridTileSize;
            float ypos = (float) Math.random() * gridHeight * gridTileSize;
            Particles[1][1].add(new Particle(xpos, ypos, (float) (Math.random() - 0.2) * 2 * MaxInitialVelocity, (float) (Math.random() - 0.2) * 2 * MaxInitialVelocity));
            Particle p = Particles[1][1].get(Particles[1][1].size() - 1);

            double count = 0;
            double rand = Math.random() * typeabundanceTotal;
            for (int i2 = 0; i2 < typeabundance.length; i2++) {
                count = count+typeabundance[i2];

                if(count>rand  ||  i2+1 >= typeabundance.length){
                    p.bondQuantity = i2+1;//1 + (int) Math.round((Math.random() * (numberoftypes - 1)) / (Math.pow((Math.random()) + 1, 2)));
                    break;
                }
            }
        }
    }

    public void UpdateAtomPhysics() {
        System.out.println("UpdatingOrganisms");

        for (int x = 0; x < gridWidth; x++) {
            for (int y = 0; y < gridHeight; y++) {
                //System.out.println("X-" + x + "   Y-" + y + "    Particles[x][y]: length" + Particles[x][y].size());
                for (Particle P : Particles[x][y]) {


                    // Apply forces for nearby atoms
                    double newxvel = P.Xvelocity;
                    double newyvel = P.Yvelocity;
                    for (int xx = (int)Math.floor(P.Xpos/gridTileSize-forceRadius)    ;    xx<(int)(Math.ceil(P.Xpos/gridTileSize+forceRadius) ) ;   xx++){
                        for (int yy = (int)Math.floor(P.Ypos/gridTileSize-forceRadius)    ;    yy<(int)(Math.ceil(P.Ypos/gridTileSize+forceRadius) )  ;   yy++){

                            int xoffset = 0;
                            int yoffset = 0;

                            if(xx<0){xoffset=1;}
                            if(xx>=gridWidth){xoffset=-1;}
                            if(yy<0){yoffset=1;}
                            if(yy>=gridHeight){yoffset=-1;}

                            for (Particle p : Particles[xx+xoffset*gridWidth][yy+yoffset*gridHeight]) {
                                if(!(p.Xpos==P.Xpos || p.Ypos == P.Ypos)) {
                                    if(P.covalentBonds.contains(p)){

                                        // just like for general interactions the offsets here are for handling cases where particles interact over the boundary as it wraps round
                                        xoffset = 0;
                                        yoffset = 0;
                                        //int xx = (int)Math.floor(p.Xpos/gridTileSize);
                                        //int yy = (int)Math.floor(P.Xpos/gridTileSize);
                        /*
                        if(P.Xpos-particle.Xpos<0){xoffset=1;}
                        if(P.Xpos-particle.Xpos>=gridWidth){xoffset=-1;}
                        if(P.Ypos-particle.Ypos<0){yoffset=1;}
                        if(P.Ypos-particle.Ypos>=gridHeight){yoffset=-1;}*/
                                        double xdifference = p.Xpos - P.Xpos ;
                                        double ydifference = p.Ypos - P.Ypos ;
                                        double xdifference2 = p.Xpos - P.Xpos + gridTileSize*gridWidth ;
                                        double ydifference2 = p.Ypos - P.Ypos + gridTileSize*gridHeight ;
                                        double xdifference3 = p.Xpos - P.Xpos - gridTileSize*gridWidth ;
                                        double ydifference3 = p.Ypos - P.Ypos - gridTileSize*gridHeight ;
                                        if(Math.abs(xdifference2)<Math.abs(xdifference)){xdifference=xdifference2;}
                                        if(Math.abs(xdifference3)<Math.abs(xdifference)){xdifference=xdifference3;}
                                        if(Math.abs(ydifference2)<Math.abs(ydifference)){ydifference=ydifference2;}
                                        if(Math.abs(ydifference3)<Math.abs(ydifference)){ydifference=ydifference3;}
                                        double distance = Math.sqrt(Math.pow(xdifference,2)+Math.pow(ydifference,2));

                                        if(distance>bondBreakMultiplier*(p.OuterRadius+P.OuterRadius)){
                                            p.covalentBonds.remove(P);
                                            P.covalentBonds.remove(p);
                                        }else{
                                            double futuredistance = Math.sqrt(Math.pow(xdifference + P.Xvelocity * speed - p.Xvelocity * speed, 2) + Math.pow(ydifference + P.Yvelocity * speed - p.Yvelocity * speed, 2));
                                            // need to dampen velocity towards atom but not rotationally

                                            double force = (distance - (P.OuterRadius + p.OuterRadius)) * 60000 + (p.OuterRadius - P.OuterRadius) * 6000;
                                            double relativeVelocityX = p.Xvelocity - P.Xvelocity;
                                            double relativeVelocityY = p.Yvelocity - P.Yvelocity;
                                            double tangentslope = relativeVelocityY / relativeVelocityX;
                                            double normalX =

                                                    newxvel = newxvel + (p.Xvelocity - P.Xvelocity) * speed * 506f / distance + xdifference * force * speed; //repulsive force
                                            newyvel = newyvel + (p.Yvelocity - P.Yvelocity) * speed * 506f / distance + ydifference * force * speed;
                                        }
                                    }else {
                                        double xdifference = p.Xpos - P.Xpos - xoffset * gridWidth * gridTileSize;
                                        double ydifference = p.Ypos - P.Ypos - yoffset * gridHeight * gridTileSize;
                                        double distance = Math.sqrt(Math.pow(xdifference, 2) + Math.pow(ydifference, 2));

                                        System.out.println("PHYSICS differencex = " + xdifference);
                                        // newxvel =newxvel + (float) ((xdifference/distance) * speed*10);// attractive force
                                        // newyvel = newyvel + (float) ((ydifference/distance) * speed*10);
                                        double force = -500000/Math.pow(distance,3)+1000 * ((distance / 10 - 1) / (Math.abs(Math.pow(distance / 10, 4)) + 1 - .1 / distance));
                                        //if(force>0)force=0;
                                        newxvel = newxvel + (p.Xvelocity - P.Xvelocity) * speed * .15f / distance + xdifference * force * speed; //repulsive force
                                        newyvel = newyvel + (p.Yvelocity - P.Yvelocity) * speed * .15f / distance + ydifference * force * speed;

                                        if (P.covalentBonds.size() < P.bondQuantity && p.covalentBonds.size() < p.bondQuantity) {
                                            if (P.OuterRadius + p.OuterRadius > distance / bondFormMultiplier) {
                                                p.covalentBonds.add(P);
                                                P.covalentBonds.add(p);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if(P==null){
                        System.out.println("Null   P");
                    }
                    //Apply forces of covalent bonds
                    /*
                    for(Particle particle : P.covalentBonds){

                        // just like for general interactions the offsets here are for handling cases where particles interact over the boundary as it wraps round
                        int xoffset = 0;
                        int yoffset = 0;
                        //int xx = (int)Math.floor(p.Xpos/gridTileSize);
                        //int yy = (int)Math.floor(P.Xpos/gridTileSize);
                        /*
                        if(P.Xpos-particle.Xpos<0){xoffset=1;}
                        if(P.Xpos-particle.Xpos>=gridWidth){xoffset=-1;}
                        if(P.Ypos-particle.Ypos<0){yoffset=1;}
                        if(P.Ypos-particle.Ypos>=gridHeight){yoffset=-1;}*/
                    /*
                        double xdifference = particle.Xpos - P.Xpos ;
                        double ydifference = particle.Ypos - P.Ypos ;
                        double xdifference2 = particle.Xpos - P.Xpos + gridTileSize*gridWidth ;
                        double ydifference2 = particle.Ypos - P.Ypos + gridTileSize*gridHeight ;
                        double xdifference3 = particle.Xpos - P.Xpos - gridTileSize*gridWidth ;
                        double ydifference3 = particle.Ypos - P.Ypos - gridTileSize*gridHeight ;
                        if(Math.abs(xdifference2)<Math.abs(xdifference)){xdifference=xdifference2;}
                        if(Math.abs(xdifference3)<Math.abs(xdifference)){xdifference=xdifference3;}
                        if(Math.abs(ydifference2)<Math.abs(ydifference)){ydifference=ydifference2;}
                        if(Math.abs(ydifference3)<Math.abs(ydifference)){ydifference=ydifference3;}
                        double distance = Math.sqrt(Math.pow(xdifference,2)+Math.pow(ydifference,2));

                        double force = (distance-(P.OuterRadius+particle.OuterRadius))*1000 ;



                        newxvel = newxvel +(particle.Xvelocity-P.Xvelocity)*speed*160f/distance+ xdifference *  force*speed; //repulsive force
                        newyvel = newyvel +(particle.Yvelocity-P.Yvelocity)*speed*160f/distance+ ydifference *  force*speed;
                    }
*/

                    P.newXvelocity =newxvel*(1+dragfactor*speed);
                    P.newYvelocity =newyvel*(1+dragfactor*speed);
                    P.newXpos = P.Xpos + P.Xvelocity*speed;
                    P.newYpos = P.Ypos + P.Yvelocity*speed;
                    // wrap position back round onto valid area before updating which array its in
                    double xposoffset = Math.floor(P.newXpos/(gridTileSize*gridWidth))*gridTileSize*gridWidth;
                    P.newXpos = P.newXpos- xposoffset;

                    double yposoffset = Math.floor(P.newYpos/(gridTileSize*gridHeight))*gridTileSize*gridHeight;
                    P.newYpos = P.newYpos- yposoffset;

                }
            }
        }


        for(int x = 0; x<gridWidth ; x++){
            for(int y = 0; y<gridHeight ; y++) {
                System.out.println("X-"+x+"   Y-"+y+"    Particles[x][y]: length"+Particles[x][y].size());
                for(Particle P:Particles[x][y]){
                    P.Xvelocity = P.newXvelocity;
                    P.Yvelocity = P.newYvelocity;
                    P.Xpos = P.newXpos;
                    P.Ypos = P.newYpos;


                    /*if(P.Xpos<0){
                        P.Xpos = P.Xpos + gridTileSize*gridWidth;
                    }
                    if(P.Ypos<0){
                        P.Ypos = P.Ypos + gridTileSize*gridHeight;
                    }
                    if(Math.floor(P.Xpos)>=gridTileSize*gridWidth){
                        P.Xpos = P.Xpos - gridTileSize*gridWidth;
                    }
                    if(Math.floor(P.Ypos)>=gridTileSize*gridHeight){
                        P.Ypos = P.Ypos - gridTileSize*gridHeight;
                    }*/
                }
            }
        }

        for(int x = 0; x<gridWidth ; x++) {
            for (int y = 0; y < gridHeight; y++) {
                ArrayList<Particle> list = Particles[x][y];
                for (int n =  list.size()-1;n>=0;n--) {
                    Particle P = list.get(n);
                    if ((int) Math.floor(P.Xpos/gridTileSize) != x || (int) Math.floor(P.Ypos/gridTileSize) != y) {
                        // move to another box
                        int correctx = (int) Math.floor(P.Xpos/gridTileSize);
                        int correcty = (int) Math.floor(P.Ypos/gridTileSize);
                        Particles[correctx][correcty].add(P);
                        list.remove(n);
                    }
                }
            }
        }
    }

    public void UpdateDisplay(){
        BufferedImage ig =new BufferedImage(windowWidth, windowHeight,
                BufferedImage.TYPE_INT_ARGB_PRE);
        Graphics g = ig.getGraphics();
        displayiterator =0;
        g.clearRect(0,0,windowWidth,windowHeight);

        g.setColor(Color.gray);
        g.fillRect(0,0,gridTileSize*scale*gridWidth,gridTileSize*scale*gridHeight);
        //---------- Gridlines diplay code -----------
        /*
        for(int x = 0; x<gridWidth ; x++){
            for(int y = 0; y<gridHeight ; y++){
                if(Particles[x][y].size()>0){
                    g.setColor(Color.darkGray);
                    g.fillRect(x*gridTileSize*scale,y*gridTileSize*scale,gridTileSize*scale,gridTileSize*scale);
                }
                g.setColor(Color.gray);
                g.drawRect(x*gridTileSize*scale,y*gridTileSize*scale,gridTileSize*scale,gridTileSize*scale);

            }
        }

         */


        //---------- Organism display code -----------
        for (ArrayList<Particle>[] PArrArr : Particles){

            for (ArrayList<Particle> PArr : PArrArr) {


                for (Particle P : PArr) {

                    System.out.println((float)(P.bondQuantity-1) /(1+typeabundance.length) + "  =  " +(P.bondQuantity-1)+"  /   "+(1+typeabundance.length));
                    g.setColor(new Color((float)(P.bondQuantity-1) /(1+typeabundance.length),0f,0f));
                    g.fillRect((int) Math.round(P.Xpos * scale-scale/2), (int) Math.round(P.Ypos * scale-scale/2), scale, scale);
                    g.setColor(Color.white);
                    //g.drawRect((int) Math.round(P.Xpos * scale), (int) Math.round(P.Ypos * scale), scale, scale);
                    for(Particle particle : P.covalentBonds) {
                        int xoffset = 0;
                        int yoffset = 0;
                        int xx = (int)Math.floor(P.Xpos/gridTileSize);
                        int yy = (int)Math.floor(P.Xpos/gridTileSize);
                        if(xx<0){xoffset=1;}
                        if(xx>=gridWidth){xoffset=-1;}
                        if(yy<0){yoffset=1;}
                        if(yy>=gridHeight){yoffset=-1;}
                        double xdifference = particle.Xpos - P.Xpos - xoffset * gridWidth * gridTileSize;
                        double ydifference = particle.Ypos - P.Ypos - yoffset * gridHeight * gridTileSize;
                        double xdifference2 = particle.Xpos - P.Xpos + gridTileSize*gridWidth ;
                        double ydifference2 = particle.Ypos - P.Ypos + gridTileSize*gridHeight ;
                        double xdifference3 = particle.Xpos - P.Xpos - gridTileSize*gridWidth ;
                        double ydifference3 = particle.Ypos - P.Ypos - gridTileSize*gridHeight ;
                        if(Math.abs(xdifference2)<Math.abs(xdifference)){xdifference=xdifference2;}
                        if(Math.abs(xdifference3)<Math.abs(xdifference)){xdifference=xdifference3;}
                        if(Math.abs(ydifference2)<Math.abs(ydifference)){ydifference=ydifference2;}
                        if(Math.abs(ydifference3)<Math.abs(ydifference)){ydifference=ydifference3;}

                        g.drawLine((int)(P.Xpos*scale),(int)(P.Ypos*scale),(int)(P.Xpos*(float)scale+xdifference*(float)scale*.5f)+xoffset*gridWidth*gridTileSize*scale,(int)(P.Ypos*(float)scale+ydifference*(float)scale*.5f+yoffset*gridWidth*gridTileSize*scale));
                    }
                }
            }
        }

        g.dispose();
        img = ig;
        repaint();
    }

    public void Update(){
        //Update organisms
        UpdateAtomPhysics();


        //Display loop
        if(displayiterator ==iteratortime) {
            UpdateDisplay();
        }
        displayiterator++;
    }

    @Override
    public void mouseDragged(MouseEvent e) {
    }

    @Override
    public void mouseMoved(MouseEvent e) {

        /*
        Graphics g = img.getGraphics();
        g.setColor(Color.RED);  // SET A COLOR
        g.drawRect(1, 1, windowWidth - 2, windowHeight - 2);

        // DO SOMETHING UGLY
        g.setColor(Color.blue);
        Point p = e.getPoint();
        g.fillOval(p.x,p.y,5,5);

        g.dispose();
        repaint();*/
    }
    @Override
    public void paintComponent(Graphics g) {
        g.drawImage(img, 0, 0, null);
    }
}
