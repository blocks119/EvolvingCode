package com.Nano;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.ArrayList;
import javax.swing.*;



public class Main extends JPanel implements MouseMotionListener {

    public static void main(String[] args) {
        new Main();
    }

    final static int windowWidth = 1000;
    final static int windowHeight = 800;

    final static int gridQuantity = 4;
    final static int arrayWidth = 50;
    final static int arrayHeight = 50;
    static int scale = 7;
    static int displayiterator = 0;
    static int iteratortime = 2;

    static float[][][] grid;

    static int redID = 2;
    static int greenID = 3;
    static int blueID = 1;
    static ArrayList<Organism> organisms;
    static float OrganismDrag = 1.07f;
    static int OrganismQuantity =  100;
    static float OrganismPushMultiplier = -.015f;
    static int OrganismForceApplyingGrid = 1;
    static int OrganismBrushradius = 1;

    static int Brushradius = 4;
    static float OrganismBrushstrength = .2f;
    BufferedImage img;
    Main() {

        img = new BufferedImage(windowWidth, windowHeight,
                BufferedImage.TYPE_INT_ARGB_PRE);
        // do in preference to setting the frame size..
        setPreferredSize(new Dimension(windowWidth, windowHeight));


        JFrame frame = new JFrame();
             this.addMouseMotionListener(this); // INSTEAD OF THE FRAME
        frame.add(this);
        //frame.setSize(width, height);  DO INSTEAD...
        frame.pack();
        //frame.setEnabled(true);  REDUNDANT
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  // good call!

        Start();
        while (true) {
            Update();
        }
    }

    public void Start() {
        Graphics g = img.getGraphics();
        grid = new float[gridQuantity][arrayWidth][arrayHeight];

        // Fill new grid with random numbers
        for (int x = 0 ;arrayWidth>x;x++
        ) {
            for (int y = 0; arrayHeight  > y; y++
            ) {
                for(int i = 0; i<gridQuantity;i++)
                grid[i][x][y] = (float)Math.random();
            }
        }


        /*
        g.setColor(Color.RED);  // SET A COLOR
        g.drawRect(1, 1, windowWidth - 2, windowHeight - 2);

        // DO SOMETHING UGLY
        g.setColor(Color.green);
        Point p = new Point(20,20);
        g.fillOval(p.x,p.y,5,5);
        */
        g.dispose();
        repaint();
        organisms = new ArrayList();
        for(int i = 0;i<OrganismQuantity;i++) {

            organisms.add(new Organism((float)Math.floor(Math.random()*arrayWidth), (float)Math.floor(Math.random()*arrayHeight)));
        }

    }

    public float Average(int xpos,int ypos,float rf,int gridID){
        int r = (int)Math.ceil(rf);
        float average = 0;
        float divisionfactor = 0;
        for (int x = -r;r >= x;x++
        ) {
            for (int y = -r; r  >= y; y++
            ) {
                int X;
                int Y;
                //float factor = (float) Math.sqrt(Math.pow(Math.abs(x),2)+Math.pow(Math.abs(y),2))  / rf;
                float factor =  rf - (float)Math.sqrt(Math.pow(Math.abs(x),2)+Math.pow(Math.abs(y),2)) ;
                if(factor<0)factor=0;
                if (x + xpos < 0) {
                    X = x + xpos + arrayWidth;
                } else if (x + xpos >= arrayWidth ) {
                    X = x + xpos - arrayWidth;
                } else {
                    X = x + xpos;
                }
                if (y + ypos < 0) {
                    Y = y + ypos + arrayHeight;
                } else if (y + ypos >= arrayHeight ) {
                    Y = y + ypos - arrayHeight;
                } else {
                    Y = y + ypos;
                }
                divisionfactor = divisionfactor + factor;
                average = average + grid[gridID][X][Y]*factor;
            }
        }
        average = average/divisionfactor;//((r*2+1)*(r*2+1));
        return average;
    }

    public void UpdateGrid(){
        float[][][] newgrid =  new float[gridQuantity][arrayWidth][arrayHeight];
        for (int x = 0 ;arrayWidth > x;x++
        ) {
            for (int y = 0; arrayHeight > y; y++
            ) {
                if(x>=0 && x <= grid[0].length && y>=0 &&y <= grid[0][0].length) {
                    //(grid[x][y]+grid[x-1][y]+grid[x+1][y]+grid[x][y-1]+grid[x][y+1])/5
                    //newgrid[0][x][y] = (grid[0][x][y] - Average(x,y,1,0)  +Average(x,y,5,0));//   +(float)Math.random()/2-0.25f;// grid[x][y] - ((grid[x-1][y]+grid[x+1][y]+grid[x][y-1]+grid[x][y+1])/4 -grid[x][y])/5;


                    /*newgrid[0][x][y] = Average(x,y,3,0)*2 - Average(x,y,1,1);
                    newgrid[1][x][y] = (Average(x,y,3,0));
                    newgrid[2][x][y] = Average(x,y,3,0);*/

                    /*
                    newgrid[0][x][y] = Average(x,y,1,0)*2 - Average(x,y,2,1) -.1f;
                    newgrid[1][x][y] = (Average(x,y,1.6,0)-.4f)*3;
                    newgrid[2][x][y] = (Average(x,y,1.6,0) + Average(x,y,1.6,2)*3)/4;
                    */
//Dividing dots
                    /*
                    newgrid[0][x][y] = Average(x,y,1f,0)*2 - Average(x,y,1.5f,1) -.03f - grid[2][x][y];
                    newgrid[1][x][y] = (Average(x,y,1.6f,0)-.4f)*3;
                    newgrid[2][x][y] = (Average(x,y,1.6f,0) + Average(x,y,1.1f,2)*6)/7;


 */
/*
                    newgrid[0][x][y] = -Average(x,y,4f,0)*3+ Average(x,y,2.5f,0)*5  -.03f - grid[2][x][y];
                    newgrid[1][x][y] = Average(x,y,1f,1) -.5f + (Average(x,y,1.6f,0)-.4f)*3 +(Average(x,y,1.6f,3));
                    newgrid[2][x][y] = (-Average(x,y,1f,1) +Average(x,y,2f,0) + Average(x,y,4f,2)*6)/8;
                    newgrid[3][x][y] = Average(x,y,4f,3) + Average(x,y,1.4f,2);
*/
                    //Atoms

                    newgrid[0][x][y] = Average(x,y,1.5f,0)*1.1f-0.15f - (float)Math.pow(grid[0][x][y]/3,2);
                    newgrid[1][x][y] = Average(x,y, 3f,3)*.1f+Average(x,y,.3f,2)*.3f   +  Average(x,y,2f,0)*1f    -     Average(x,y,4f,0)*1.8f     +   Average(x,y,9f,0)*1f  +0.02f;
                    newgrid[2][x][y] = Average(x,y,9f,1)*2f ;
                    newgrid[3][x][y] = Average(x,y, 5f,3)+.01f-Average(x,y, 2f,1)*.1f;

/*
                    newgrid[0][x][y] = Average(x,y,1.2f,0)*1.1f-0.05f - (float)Math.pow(grid[0][x][y]/3,2) +(float)Math.pow(Average(x,y, .1f,2),1f)*.01f;
                    newgrid[1][x][y] = Average(x,y, 1.1f,3)*.1f+Average(x,y,.3f,2)*.3f   +  Average(x,y,2f,0)*1f    -     Average(x,y,4f,0)*1.8f     +   Average(x,y,9f,0)*1f  +0.02f;
                    newgrid[2][x][y] = Average(x,y,1.3f,2)*1.7f  -  Average(x,y,1.3f,3)*1f + Average(x,y,.3f,0)*.9f;
                    newgrid[3][x][y] = Average(x,y, .8f,3)*1f -.10561f  + Average(x,y, 2f,2)*0.3f +Average(x,y,1.3f,0)*.9f;
                    */
                    //New Loopy rings after code fix

                    /*
                    newgrid[0][x][y] = Average(x,y,1.8f,0)*2 - Average(x,y,2.2f,1) -.03f - grid[2][x][y];
                    newgrid[1][x][y] = (Average(x,y,2.5f,0)-.4f)*3;
                    newgrid[2][x][y] = (Average(x,y,2.5f,0) + Average(x,y,1.9f,2)*6)/7;*/

                    //growing lines/boxes
                    /*
                    newgrid[0][x][y] = Average(x,y,1.3f,0)*2 - Average(x,y,2.2f,1) -.03f - grid[2][x][y];
                    newgrid[1][x][y] = (Average(x,y,2.5f,0)-.4f)*3;
                    newgrid[2][x][y] = (Average(x,y,2.5f,0) + Average(x,y,1.9f,2)*6)/7;*/

                    /*
                    newgrid[0][x][y] = Average(x,y,1.7f,0)*2.4f - Average(x,y,1.3f,1) -.01f - grid[2][x][y] + grid[3][x][y]-.55f;
                    newgrid[1][x][y] = (Average(x,y,1.5f,0)-.4f)*2 +0.1f;
                    newgrid[2][x][y] = (Average(x,y,.1f,0)*1.2f + Average(x,y,1.1f,2)*5)/6 ;
                    newgrid[3][x][y] = Average(x,y,1.5f,1)*4.4f;

                    */
                    //Spirals
                    /*
                    newgrid[0][x][y] = Average(x,y,1f,0)*2f + Average(x,y,3f,1) -.01f - grid[2][x][y]*3.6f + grid[3][x][y]-.95f;
                    newgrid[1][x][y] = (Average(x,y,.9f,0)-.4f)*3.1f+0.1f;
                    newgrid[2][x][y] = ((Average(x,y,.1f,0)-.36f)*1.1f + Average(x,y,0.1f,2)*5)/6 ;
                    newgrid[3][x][y] = Average(x,y,5f,1)*4.4f;

                     */

                    /*
                    newgrid[0][x][y] = Average(x,y,2f,0)*2f + Average(x,y,3f,1) -.01f - grid[2][x][y]*3.2f + grid[3][x][y]-.95f;
                    newgrid[1][x][y] = (Average(x,y,1.9f,0)-.4f)*3.1f+0.1f;
                    newgrid[2][x][y] = ((Average(x,y,1.2f,0)-.36f)*1.1f + Average(x,y,0.3f,2)*3)/4 ;
                    newgrid[3][x][y] = Average(x,y,3f,1)*4.4f;
                    */

                }else {
                    newgrid[0][x][y] =1;// grid[0][x][y];
                }
                for(int i = 0;i<gridQuantity;i++) {
                    // Limit the values of grid tiles
                    //if (newgrid[i][x][y] > 1) newgrid[i][x][y] = 1;
                    if (newgrid[i][x][y] < 0) newgrid[i][x][y] = 0;
                }

                /*if(x >= grid.length -2){
                    grid[x][y] = grid[0][y];

                }else {
                    grid[x][y] = grid[x + 1][y];
                }
                */



            }
        }
        grid=newgrid;
    }

    public void UpdateOrganisms(){
        for (Organism O :organisms) {
            int xint = (int) Math.round(O.Xpos);
            int yint = (int) Math.round(O.Ypos);
            if(xint>=arrayWidth){xint=xint-arrayWidth;}
            if(yint>=arrayHeight){yint=yint-arrayHeight;}

            float Xgradient;
            float Ygradient;
            if (xint - 1 > 0) {
                if (xint + 1 < arrayWidth) {
                    Xgradient = grid[OrganismForceApplyingGrid][xint - 1][yint] - grid[OrganismForceApplyingGrid][xint + 1][yint];
                } else {
                    Xgradient = grid[OrganismForceApplyingGrid][xint - 1][yint] - grid[OrganismForceApplyingGrid][xint + 1 - arrayWidth][yint];
                }
            } else {
                Xgradient = grid[OrganismForceApplyingGrid][xint - 2 + arrayWidth][yint] - grid[OrganismForceApplyingGrid][xint + 1][yint];
            }
            if (yint - 1 > 0) {
                if (yint + 1 < arrayHeight) {
                    Ygradient = grid[OrganismForceApplyingGrid][xint][yint - 1] - grid[OrganismForceApplyingGrid][xint][yint + 1];
                } else {
                    Ygradient = grid[OrganismForceApplyingGrid][xint][yint - 1] - grid[OrganismForceApplyingGrid][xint][yint + 1 - arrayHeight];
                }
            } else {
                Ygradient = grid[OrganismForceApplyingGrid][xint][yint - 2 + arrayHeight] - grid[OrganismForceApplyingGrid][xint][+1];
            }
            O.Xvelocity = O.Xvelocity / OrganismDrag + Xgradient * OrganismPushMultiplier;
            O.Xpos = O.Xpos + O.Xvelocity;

            O.Yvelocity = O.Yvelocity / OrganismDrag + Ygradient * OrganismPushMultiplier;
            O.Ypos = O.Ypos + O.Yvelocity;

            if (O.Xpos < 0) O.Xpos = O.Xpos + arrayWidth;
            if (O.Ypos < 0) O.Ypos = O.Ypos + arrayHeight;
            if (O.Xpos >= arrayWidth) O.Xpos = O.Xpos - arrayWidth;
            if (O.Ypos >= arrayHeight) O.Ypos = O.Ypos - arrayHeight;


            for (int x = -OrganismBrushradius; OrganismBrushradius >= x; x++) {
                for (int y = -OrganismBrushradius; OrganismBrushradius >= y; y++) {
                    System.out.println("hi");
                    int ix = (int) Math.round(O.Xpos) + x;
                    int iy = (int) Math.round(O.Ypos) + y;

                    if (ix < 0) ix = arrayWidth + ix;
                    if (iy < 0) iy = arrayHeight + iy;
                    if (ix >= arrayWidth) ix = -arrayWidth + ix;
                    if (iy >= arrayHeight) iy = -arrayHeight + iy;
                    grid[0][ix][iy] = grid[0][ix][iy] + OrganismBrushstrength;
                }
            }
        }
    }

    public void Update() {

        //Update Grid
        UpdateGrid();
        //Update organisms
        UpdateOrganisms();


        //Display loop
        if(displayiterator ==iteratortime) {
            Graphics g = img.getGraphics();
            displayiterator =0;
            for (int x = 0; arrayWidth-1 > x; x++
            ) {
                for (int y = 0; arrayHeight-1 > y; y++
                ) {
                    float fr;
                    float fg;
                    float fb;

                    // ----------Unsmoothed display code -------------
                    /*
                    fr = newgrid[0][x][y];
                    fg = newgrid[1][x][y];
                    fb = newgrid[2][x][y];
                    g.setColor(new Color(fr, fg, fb));
                    g.fillRect(x * scale, y * scale, scale, scale);
                    */
                    // ----------Smoothed display code -------------
                    for (int scaledx = 0; scaledx < scale; scaledx++) {
                        for (int scaledy = 0; scaledy < scale; scaledy++) {
                            if (x < arrayWidth - 1 && y < arrayHeight - 1) {

                                float xy = 1 - (float) Math.sqrt(Math.pow(Math.abs(scaledx / (float) scale), 2) + Math.pow(Math.abs(scaledy / (float) scale), 2));
                                float Xy = 1 - (float) Math.sqrt(Math.pow(Math.abs(1 - scaledx / (float) scale), 2) + Math.pow(Math.abs(scaledy / (float) scale), 2));
                                float xY = 1 - (float) Math.sqrt(Math.pow(Math.abs(scaledx / (float) scale), 2) + Math.pow(Math.abs(1 - scaledy / (float) scale), 2));
                                float XY = 1 - (float) Math.sqrt(Math.pow(Math.abs(1 - scaledx / (float) scale), 2) + Math.pow(Math.abs(1 - scaledy / (float) scale), 2));


                            /*
                            float xy =   Math.min(1-scaledx/scale,1-scaledy/scale)  ;
                            float Xy =  0;//  Math.min(scaledx/scale,1-scaledy/scale)  ;
                            float xY =  0;//  Math.min(1-scaledx/scale,scaledy/scale)  ;
                            float XY =   0;// Math.min(scaledx/scale,scaledy/scale)  ;
                            */
                            /*
                            fr = (newgrid[0][x][y] * (scaledx / (float)scale) + newgrid[0][x + 1][y] * (1 - scaledx / (float)scale)) * (scaledy / (float)scale)    +    (newgrid[0][x][y+1] * (scaledx / (float)scale) + newgrid[0][x + 1][y+1] * (1 - scaledx / (float)scale)) * (1 - scaledy / (float)scale);
                            fg = (newgrid[1][x][y] * (scaledx / (float)scale) + newgrid[1][x + 1][y] * (1 - scaledx / (float)scale)) * (scaledy / (float)scale)    +    (newgrid[1][x][y+1] * (scaledx / (float)scale) + newgrid[1][x + 1][y+1] * (1 - scaledx / (float)scale)) * (1 - scaledy / (float)scale);
                            fb = (newgrid[2][x][y] * (scaledx / (float)scale) + newgrid[2][x + 1][y] * (1 - scaledx / (float)scale)) * (scaledy / (float)scale)    +    (newgrid[2][x][y+1] * (scaledx / (float)scale) + newgrid[2][x + 1][y+1] * (1 - scaledx / (float)scale)) * (1 - scaledy / (float)scale);
                            */

                                fr = grid[redID][x][y] * xy + grid[redID][x + 1][y] * Xy + grid[redID][x][y + 1] * xY + grid[redID][x + 1][y + 1] * XY;
                                fg = grid[greenID][x][y] * xy + grid[greenID][x + 1][y] * Xy + grid[greenID][x][y + 1] * xY + grid[greenID][x + 1][y + 1] * XY;
                                fb = grid[blueID][x][y] * xy + grid[blueID][x + 1][y] * Xy + grid[blueID][x][y + 1] * xY + grid[blueID][x + 1][y + 1] * XY;
                                if (fr > 1) fr = 1;
                                if (fg > 1) fg = 1;
                                if (fb > 1) fb = 1;
                                if (fr < 0) fr = 0;
                                if (fg < 0) fg = 0;
                                if (fb < 0) fb = 0;

                                g.setColor(new Color(fr, fg, fb));

                                g.drawRect(x * scale + scaledx, y * scale + scaledy, 1, 1);

                            } else { // this code should be inaccessible
                                fr = grid[0][x][y];
                                fg = grid[1][x][y];
                                fb = grid[2][x][y];
                                g.setColor(new Color(fr, fg, fb));
                                g.fillRect(x * scale + scaledx, y * scale + scaledy, 1, 1);
                            }


                        }
                    }
                    for (int scaledx = 0; scaledx < scale; scaledx++) {
                        for (int scaledy = 0; scaledy < scale; scaledy++) {
                            if (x < arrayWidth - 1 && y < arrayHeight - 1) {

                                float xy = 1 - (float) Math.sqrt(Math.pow(Math.abs(scaledx / (float) scale), 2) + Math.pow(Math.abs(scaledy / (float) scale), 2));
                                float Xy = 1 - (float) Math.sqrt(Math.pow(Math.abs(1 - scaledx / (float) scale), 2) + Math.pow(Math.abs(scaledy / (float) scale), 2));
                                float xY = 1 - (float) Math.sqrt(Math.pow(Math.abs(scaledx / (float) scale), 2) + Math.pow(Math.abs(1 - scaledy / (float) scale), 2));
                                float XY = 1 - (float) Math.sqrt(Math.pow(Math.abs(1 - scaledx / (float) scale), 2) + Math.pow(Math.abs(1 - scaledy / (float) scale), 2));


                            /*
                            float xy =   Math.min(1-scaledx/scale,1-scaledy/scale)  ;
                            float Xy =  0;//  Math.min(scaledx/scale,1-scaledy/scale)  ;
                            float xY =  0;//  Math.min(1-scaledx/scale,scaledy/scale)  ;
                            float XY =   0;// Math.min(scaledx/scale,scaledy/scale)  ;
                            */
                            /*
                            fr = (newgrid[0][x][y] * (scaledx / (float)scale) + newgrid[0][x + 1][y] * (1 - scaledx / (float)scale)) * (scaledy / (float)scale)    +    (newgrid[0][x][y+1] * (scaledx / (float)scale) + newgrid[0][x + 1][y+1] * (1 - scaledx / (float)scale)) * (1 - scaledy / (float)scale);
                            fg = (newgrid[1][x][y] * (scaledx / (float)scale) + newgrid[1][x + 1][y] * (1 - scaledx / (float)scale)) * (scaledy / (float)scale)    +    (newgrid[1][x][y+1] * (scaledx / (float)scale) + newgrid[1][x + 1][y+1] * (1 - scaledx / (float)scale)) * (1 - scaledy / (float)scale);
                            fb = (newgrid[2][x][y] * (scaledx / (float)scale) + newgrid[2][x + 1][y] * (1 - scaledx / (float)scale)) * (scaledy / (float)scale)    +    (newgrid[2][x][y+1] * (scaledx / (float)scale) + newgrid[2][x + 1][y+1] * (1 - scaledx / (float)scale)) * (1 - scaledy / (float)scale);
                            */

                                fr = grid[redID][x][y] * xy + grid[redID][x + 1][y] * Xy + grid[redID][x][y + 1] * xY + grid[redID][x + 1][y + 1] * XY;
                                fg = grid[greenID][x][y] * xy + grid[greenID][x + 1][y] * Xy + grid[greenID][x][y + 1] * xY + grid[greenID][x + 1][y + 1] * XY;
                                fb = grid[blueID][x][y] * xy + grid[blueID][x + 1][y] * Xy + grid[blueID][x][y + 1] * xY + grid[blueID][x + 1][y + 1] * XY;
                                if (fr > 1) fr = 1;
                                if (fg > 1) fg = 1;
                                if (fb > 1) fb = 1;
                                if (fr < 0) fr = 0;
                                if (fg < 0) fg = 0;
                                if (fb < 0) fb = 0;

                                g.setColor(new Color(fr, fg, fb));

                                g.drawRect(x * scale + scaledx+arrayWidth*scale-scale, y * scale + scaledy, 1, 1);

                            } else { // this code should be inaccessible
                                fr = grid[0][x][y];
                                fg = grid[1][x][y];
                                fb = grid[2][x][y];
                                g.setColor(new Color(fr, fg, fb));
                                g.fillRect(x * scale + scaledx+arrayWidth, y * scale + scaledy+arrayHeight, 1, 1);
                            }


                        }
                    }



                }
            }
            //---------- Organism display code -----------
            for (Organism O :organisms) {


                g.setColor(Color.red);
                g.fillRect((int) Math.round(O.Xpos * scale), (int) Math.round(O.Ypos * scale), scale, scale);
                g.setColor(Color.white);
                g.drawRect((int) Math.round(O.Xpos * scale), (int) Math.round(O.Ypos * scale), scale, scale);

            }
            g.dispose();
        }

        displayiterator++;

        repaint();
    }









    @Override
    public void mouseDragged(MouseEvent e) {
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        Point p = e.getPoint();
        if(p.x>=0&&p.y>=0&& p.x<arrayWidth*scale && p.y <arrayHeight*scale){
            grid[0][p.x/scale][p.y/scale] = grid[0][p.x/scale][p.y/scale]+0.9f;
            for (int x = -Brushradius;Brushradius >= x;x++)
            {
                for (int y = -Brushradius; Brushradius >= y; y++)
                {
                    int ix = (int) Math.floor(p.x/(float)scale +x);
                    int iy = (int) Math.floor(p.y/(float)scale +y);
                    if(ix<0)ix=arrayWidth+ix;
                    if(iy<0)iy=arrayHeight+iy;
                    if(ix>=arrayWidth)ix=-arrayWidth+ix;
                    if(iy>=arrayHeight)iy=-arrayHeight+iy;
                    grid[0][ix][iy] = grid[0][ix][iy]+0.02f;
                }
            }

        }
        /*
        Graphics g = img.getGraphics();
        g.setColor(Color.RED);  // SET A COLOR
        g.drawRect(1, 1, windowWidth - 2, windowHeight - 2);

        // DO SOMETHING UGLY
        g.setColor(Color.blue);
        Point p = e.getPoint();
        g.fillOval(p.x,p.y,5,5);

        g.dispose();
        repaint();*/
    }
    @Override
    public void paintComponent(Graphics g) {
        g.drawImage(img, 0, 0, null);
    }

}