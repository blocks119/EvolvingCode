package com.Nano;

import javax.swing.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class mouse extends JPanel implements MouseListener {

    @Override
    public void mouseClicked(MouseEvent arg0) {
        System.out.println("here was a click ! ");

        int x=arg0.getX()/EvolvingAutomata.scale;
        int y=arg0.getY()/EvolvingAutomata.scale;
        if(x>0 && x<EvolvingAutomata.arrayWidth && y>0 && y<EvolvingAutomata.arrayHeight){
            EvolvingAutomata.DisplayedCellY = y;
            EvolvingAutomata.DisplayedCellX = x;
            EvolvingAutomata.displayedCell = cell.copy(EvolvingAutomata.grid[x][y],false);
        }
        EvolvingAutomata.updateText=true;
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }


}