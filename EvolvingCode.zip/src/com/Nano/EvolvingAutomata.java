package com.Nano;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

class command{
    int commandID;
    float[] parameters;
    static command getRandomCommand(){
        command c = new command();
        c.commandID = (int)Math.floor(Math.random()*3);
        c.parameters = new float[6];
        for (int i = 0; i<c.parameters.length;i++) {
            c.parameters[i]=(float)Math.random()*EvolvingAutomata.intialParameterMax;
        }
        return c;
    }
    command copy(){
        command c = new command();
        c.commandID = commandID;
        c.parameters = new float[parameters.length];
        for (int i = 0; i<parameters.length;i++) {
            c.parameters[i]=parameters[i];
        }
        return c;
    }
}
class cell{
    int age;
    int startingChromosome;
    int startingGene;
    double health;
    double[] color;
    ArrayList<ArrayList<command>> Code;
    /*
    double totalenergyTransferIntent;
    double[][] energyTransferIntent;

    double[] behaviourGenes;
    double[] passivegenes;*/
    static cell copy(cell c1,boolean resetAge){
        if(c1==null){
            cell c = new cell();
            return c;
        }else {
            cell c;
            c = new cell();
            if(resetAge){
                c.age = 0;
            }else {
                c.age = c1.age;
            }
            c.startingGene = c1.startingGene;
            c.startingChromosome = c1.startingChromosome;
            c.health = c1.health;
            c.color = c1.color.clone();
            c.Code = cloneCode(c1.Code);
            return c;
        }
    }
    cell mutate(){
        color[0]=color[0]+(Math.random()-0.5f)*EvolvingAutomata.masterMutationRate;
        color[1]=color[1]+(Math.random()-0.5f)*EvolvingAutomata.masterMutationRate;
        color[2]=color[2]+(Math.random()-0.5f)*EvolvingAutomata.masterMutationRate;

        for (int i = Code.size()-1;i>=0;i--) {//foreach chromosome apply mutations
            ArrayList<command> chromosome = Code.get(i);

            if(  Math.random()  <  EvolvingAutomata.masterMutationRate*EvolvingAutomata.startPointMutationRate   ){
                startingChromosome= (int)(Math.floor(Math.random()*Code.size()));
                startingGene=(int)(Math.floor(Math.random()*Code.get(startingChromosome).size()));
            }
            if(  Math.random()  <  EvolvingAutomata.masterMutationRate*EvolvingAutomata.startGeneDriftRate   ){
                //startingChromosome= (int)Math.floor(Math.random()*Code.size());
                startingGene=startingGene+(int)((Math.random()-0.5)*4);
                if(startingGene>=Code.get(startingChromosome).size()){
                    startingGene = startingGene -Code.get(startingChromosome).size();
                }
                if(startingGene<0){
                    startingGene = startingGene +Code.get(startingChromosome).size();
                }
            }

            if(  Math.random()  <  EvolvingAutomata.masterMutationRate*EvolvingAutomata.chromosomeDuplicationRate   ){ // duplicate chromosomes
                Code.add(cell.cloneChromosome( Code.get(i) ));
                color[0]=color[0]+(Math.random()-0.5f)*EvolvingAutomata.colorMutationRate;
                color[1]=color[1]+(Math.random()-0.5f)*EvolvingAutomata.colorMutationRate;
                color[2]=color[2]+(Math.random()-0.5f)*EvolvingAutomata.colorMutationRate;
            }

            if(  Math.random()  <  EvolvingAutomata.masterMutationRate*EvolvingAutomata.geneParameterDriftRate*Code.get(i).size()   ){ // drift parameters
                command com = chromosome.get((int)Math.floor((Code.get(i).size()*0.99)*Math.random()));
                for(int i1=0; i1<com.parameters.length;i1++){
                    com.parameters[i1] = (float)( com.parameters[i1] +(Math.random()-0.5f)*EvolvingAutomata.geneDriftDistance);
                }
                color[0]=color[0]+(Math.random()-0.5f)*EvolvingAutomata.colorMutationRate*0.3f;
                color[1]=color[1]+(Math.random()-0.5f)*EvolvingAutomata.colorMutationRate*0.3f;
                color[2]=color[2]+(Math.random()-0.5f)*EvolvingAutomata.colorMutationRate*0.3f;
            }
            if(  Math.random()  <  EvolvingAutomata.masterMutationRate*EvolvingAutomata.genePointMutationRate*Code.size()   ){

                Code.get(i).set(  (int)Math.floor(Math.random()*Code.get(i).size()*0.99) ,command.getRandomCommand())  ;
                color[0]=color[0]+(Math.random()-0.5f)*EvolvingAutomata.colorMutationRate;
                color[1]=color[1]+(Math.random()-0.5f)*EvolvingAutomata.colorMutationRate;
                color[2]=color[2]+(Math.random()-0.5f)*EvolvingAutomata.colorMutationRate;
            }
            if(  Math.random()  <  EvolvingAutomata.masterMutationRate*EvolvingAutomata.genePointMutationRate*Code.size()   ){

                Code.get(i).get(  (int)Math.floor(Math.random()*Code.get(i).size()*0.99) ).commandID =(int) Math.round( Math.random()*EvolvingAutomata.intialParameterMax ) ;
                color[0]=color[0]+(Math.random()-0.5f)*EvolvingAutomata.colorMutationRate;
                color[1]=color[1]+(Math.random()-0.5f)*EvolvingAutomata.colorMutationRate;
                color[2]=color[2]+(Math.random()-0.5f)*EvolvingAutomata.colorMutationRate;
            }
            if( i>0 && Math.random()  <  EvolvingAutomata.masterMutationRate*EvolvingAutomata.chromosomeDuplicationRate*Code.size()   ){ // delete chromosomes
                Code.remove(i);
                color[0]=color[0]+(Math.random()-0.5f)*EvolvingAutomata.colorMutationRate;
                color[1]=color[1]+(Math.random()-0.5f)*EvolvingAutomata.colorMutationRate;
                color[2]=color[2]+(Math.random()-0.5f)*EvolvingAutomata.colorMutationRate;
            }


        }
        if(color[0]>1)color[0]=1;
        if(color[1]>1)color[1]=1;
        if(color[2]>1)color[2]=1;
        if(color[0]<0)color[0]=0;
        if(color[1]<0)color[1]=0;
        if(color[2]<0)color[2]=0;
        return this;
    }

    cell(){
        age = 0;
        health = EvolvingAutomata.StartingHealth;
        color=new double[3];
        color[0] = Math.random();
        color[1] = Math.random();
        color[2] = Math.random();
        Code = new ArrayList<ArrayList<command>>();
        for(int i = 0;i<EvolvingAutomata.InitialChromosomeQuantity;i++){
            Code.add(new ArrayList<command>());
            for(int i1 = 0; i1<EvolvingAutomata.InitialGeneQuantity;i1++){
                Code.get(i).add(command.getRandomCommand());
            }
        }

        startingChromosome = (int)(Math.random()*(Code.size()-1));
        startingGene = (int)(Math.random()*(Code.get(startingChromosome).size()-1));
    }
    public static ArrayList<ArrayList<command>> cloneCode(final ArrayList<ArrayList<command>> src)
    {
        ArrayList<ArrayList<command>> dest = new ArrayList<ArrayList<command>>();
        for( ArrayList<command> sublist : src) {
            ArrayList<command> temp = new ArrayList<command>();
            for(command val: sublist) {
                temp.add(val.copy());
            }
            dest.add(temp);
        }
        return dest ;
    }
    public static ArrayList<command> cloneChromosome(final ArrayList<command> src)
    {
        ArrayList<command> dest = new ArrayList<command>();

            for(command val: src) {
                dest.add(val.copy());
            }

        return dest ;
    }
}
    ;
public class EvolvingAutomata extends JPanel {
    static JPanel jpanel;
    public static void main(String[] args) {
         jpanel = new EvolvingAutomata();
    }
    static boolean paused = false;
    static boolean updateGraphicsFlag = false; // if true the graphics need a full update

    static boolean updateText = true;
    static int InitialGeneQuantity = 6;
    static int InitialChromosomeQuantity = 2; // the code is split up into multiple code sequences, each sequence can evolve to be longer or shorter or can be copied or deleted, much like chromosomes
    static double StartingHealth = 1;
    static float intialParameterMax = 5;

    static int maxage = 30;

    static float masterMutationRate = 0.0001f;
    static float chromosomeDuplicationRate=.2f;
    static float geneDuplicationRate=1;
    static float geneParameterDriftRate=5;
    static float genePointMutationRate=1;
    static float colorMutationRate = 0.1f;
    static float geneDriftDistance = 0.1f;
    static float startPointMutationRate = 0.05f;// randomises start position completely for any chromosome
    static float startGeneDriftRate = 0.1f; // shifts start position a bit within a chromosome


    static BufferedImage img;
    static BufferedImage TextImg;
    static cell[][] grid;
    static cell[][] newgrid;
    final static int windowWidth = 1920;
    final static int windowHeight = 1080;
    final static int arrayWidth = 200;
    final static int arrayHeight = 170;
    static int scale = 5;

    //Display Settings
    static boolean showKillCommands = false;
    static boolean showSelfCopyingCommands = false;

   EvolvingAutomata(){

       frame = InitializeWindow();

       Start();
       img.getGraphics().drawRect(50,50,40,20);
       while (true) {
           Update();
       }
   }
    public void Start() {
        grid = new cell[arrayWidth][arrayHeight];

        // Fill new grid with random numbers
        for (int x = 0; arrayWidth > x; x++
        ) {
            for (int y = 0; arrayHeight > y; y++
            ) {
                grid[x][y] = new cell();
                System.out.println("Created cell at "+x+" - "+y);
                if(grid[x][y]==null){
                    System.out.println("NULL");
                }
            }
        }
/*
        command c = new command();
        c.commandID = 1;
        c.parameters = new float[7];
        c.parameters[0] = 0.1f;
        c.parameters[1] = 0.1f;
        c.parameters[2] = 5.05f;
        c.parameters[3] = 1.2f;
        c.parameters[4] = 1.1f;
        c.parameters[5] = (float) Math.random()*5f;
        grid[0][0].Code.get(0).add(0,c.copy());
        grid[3][0].Code.get(0).add(1,c.copy());
        grid[5][0].Code.get(0).add(0,c.copy());
        grid[8][0].Code.get(0).add(1,c.copy());
        c.commandID = 2;
        c.parameters[0] = 0.5f;
        c.parameters[1] = 0.1f;
        c.parameters[2] = 2.05f;
        c.parameters[3] = 1.2f;
        c.parameters[4] = 1.99f;
        c.parameters[5] = (float) Math.random()*5f;
        grid[0][0].Code.get(0).add(8,c.copy());
        grid[3][0].Code.get(0).add(8,c.copy());
        grid[5][0].Code.get(0).add(8,c.copy());
        grid[8][0].Code.get(0).add(8,c.copy());
        grid[0][5].Code.get(0).add(8,c.copy());
        grid[3][5].Code.get(0).add(8,c.copy());
        grid[5][5].Code.get(0).add(8,c.copy());
        grid[8][5].Code.get(0).add(8,c.copy());
        c.commandID = 0;
        c.parameters[0] = 0.5f;
        c.parameters[1] = 0.1f;
        c.parameters[2] = 2.05f;
        c.parameters[3] = 1.2f;
        c.parameters[4] = 0.99f;
        c.parameters[5] = (float) Math.random()*5f;
        grid[0][0].Code.get(1).add(5,c.copy());
        grid[3][0].Code.get(1).add(5,c.copy());
        grid[5][0].Code.get(1).add(5,c.copy());
        grid[8][0].Code.get(1).add(5,c.copy());
        grid[0][5].Code.get(1).add(5,c.copy());
        grid[3][5].Code.get(1).add(5,c.copy());
        grid[5][5].Code.get(1).add(5,c.copy());
        grid[8][5].Code.get(1).add(5,c.copy());
*/

    }

    private static JFrame frame;
    private static JLabel label;
    private static JLabel textLabel;
    public static JFrame InitializeWindow(){
        img = new BufferedImage(windowWidth, windowHeight,
                BufferedImage.TYPE_INT_ARGB_PRE);

        //setPreferredSize(new Dimension(windowWidth, windowHeight));


        frame = new JFrame();
        frame.setBounds(0, 0, windowWidth, windowHeight);

        frame.setTitle("My Gui");



        Component mouseClick = new mouse()  ;
        frame.addMouseListener((MouseListener) mouseClick);
        //Component mouseClick = new mouse()  ;
        //frame.pack();
        //frame.setEnabled(true);  REDUNDANT

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  // good call!



        //panel.add(this);
        Container c = frame.getContentPane(); //Gets the content layer
        c.setLayout(new BorderLayout() );

        JButton killCodeButton = new JButton("Show Kill Code inserters");
        killCodeButton.setBounds(50,arrayHeight*scale+65,150,20);
        frame.add(killCodeButton);
        killCodeButton.addActionListener(e -> {
            showSelfCopyingCommands= false;
            showKillCommands = !showKillCommands;
            updateGraphicsFlag = true;
        });

        JButton viralGeneButton = new JButton("Show viral genes!");
        viralGeneButton.setBounds(50,arrayHeight*scale+15,150,20);
        frame.add(viralGeneButton);
        viralGeneButton.addActionListener(e -> {
            showSelfCopyingCommands=!showSelfCopyingCommands;
            showKillCommands = false;
            updateGraphicsFlag = true;
        });

        JButton pauseButton = new JButton("Pause");
        pauseButton.setBounds(50,arrayHeight*scale+40,150,20);
        frame.add(pauseButton);
        pauseButton.addActionListener(e -> {
            paused=!paused;
        });


        label = new JLabel(); //JLabel Creation
        //label.setIcon(new ImageIcon(img)); //Sets the image to be displayed as an icon

        Dimension size = label.getPreferredSize(); //Gets the size of the image
        label.setBounds(0, 0, size.width, size.height); //Sets the location of the image
        frame.add(label); //Adds objects to the container

        textLabel = new JLabel();
        textLabel.setBounds(arrayWidth*scale+2, 0, size.width, size.height); //Sets the location of the image
        //frame.add(textLabel); //Adds objects to the container

        frame.setVisible(true);

        return frame;
    }

    public cell mutateCell(cell c){
       return c;
    }

    public void Update(){
        if(!paused) {
            newgrid = new cell[arrayWidth][arrayHeight];
            for (int x = 0; x < arrayWidth; x++) {
                for (int y = 0; y < arrayHeight; y++) {


                    //after this bit of code ex and ey should never both be 0 at once
                    int direction = (int) (Math.random() * 8);
                    int ex = 0;
                    int ey = 0;
                    if (direction == 0 || direction == 1 || direction == 7 || direction == 8)
                        ex = -1;//incredibly rarely 8 and 1 both refer to direcly up, the rest go round clockwise
                    if (direction == 3 || direction == 4 || direction == 5) ex = 1;
                    if (direction == 1 || direction == 2 || direction == 3) ey = 1;
                    if (direction == 5 || direction == 6 || direction == 7) ey = -1;

                    int x1 = ex + x;// coordinates of the attacking cell are x1 and y1
                    int y1 = ey + y;

                    // wrap attackers coordinates round the map if near the edge
                    if (x1 < 0) {
                        x1 = x1 + arrayWidth;
                    }
                    if (x1 >= arrayWidth) {
                        x1 = x1 - arrayWidth;
                    }
                    if (y1 < 0) {
                        y1 = y1 + arrayHeight;
                    }
                    if (y1 >= arrayHeight) {
                        y1 = y1 - arrayHeight;
                    }

                    // battle the cells
                    cell newcell = battleCells(grid[x][y], grid[x1][y1]);
                    newcell.age++;
                    newgrid[x][y] = newcell;
                    // each program gets attacked randomly by one of those surrounding it ,
                    // ------ if it errors and the attacker doesnt it is replaced by a mutated full health copy of the attacker
                    // ------ if the attacker errors the attacker's health goes down but this one's health doesnt
                    // ------ if both error both have their health go down
                    // ------ if both function then both have their health go down

                    // the idea of health is to prevent code that does nothing but cant be killed from hanging arround, any that dont spread will die off unless they are exceptionally good at terminating attackers
                    // the attacker's code is run first , then the defenders
                    // whilst being run both lots of code can modify themselves or their opponent using the available commands in the language
                }
            }
        /*
        for(int x = 0;x<arrayWidth;x++){
            for(int y = 0;y<arrayHeight;y++){
                cell c= cell.copy(grid[x][y]);
                if(c.energy<0.1f||c.energy>1000){c.alive=false;} // kill if too little energy

                System.out.println("Alive = "+c.alive);
                if(c.alive) {

                    c.totalenergyTransferIntent = 0;
                    for (int ex = 0; ex < 3; ex++) {
                        for (int ey = 0; ey < 3; ey++) {


                            int x1 = ex + x-1;
                            int y1 = ey + y-1;
                            if (x1 < 0) {
                                x1 = x1 + arrayWidth;
                            }
                            if (x1 >= arrayWidth) {
                                x1 = x1 - arrayWidth;
                            }
                            if (y1 < 0) {
                                y1 = y1 + arrayHeight;
                            }
                            if (y1 >= arrayHeight) {
                                y1 = y1 - arrayHeight;
                            }


                            c.energyTransferIntent[ex][ey] = c.behaviourGenes[(ex) + (ey) * 3];// decision making here
                            c.totalenergyTransferIntent = c.totalenergyTransferIntent + c.behaviourGenes[(ex) + (ey) * 3];
                        }
                    }
                    newgrid[x][y] = c;
                }else{
                    c.energyTransferIntent= new double[3][3];
                }
                System.out.println(" en "+ c.energyTransferIntent.length);
            }
        }
        for(int x = 0;x<arrayWidth;x++){
            for(int y = 0;y<arrayHeight;y++){

                if(newgrid[x][y]==null)System.out.println("ERROR");
                cell c= cell.copy(newgrid[x][y]);
                if(c==null){c=new cell(this,false); c.wasnull= true;}
                if(c.alive)System.out.println("livecell energy ="+newgrid[x][y].behaviourGenes[0]);
                if(c.alive) {

                    c.energy = c.energy-((c.totalenergyTransferIntent-c.energyTransferIntent[1][1])/c.totalenergyTransferIntent)*c.energy ;
                    for (int ex = 0; ex < 3; ex++) {
                        for (int ey = 0; ey < 3; ey++) {
                            if(!(ex==1&&ey==1)) {
                                cell cell1;
                                int x1 = ex + x - 1;
                                int y1 = ey + y - 1;
                                if (x1 < 0) {
                                    x1 = x1 + arrayWidth;
                                }
                                if (x1 >= arrayWidth) {
                                    x1 = x1 - arrayWidth;
                                }
                                if (y1 < 0) {
                                    y1 = y1 + arrayHeight;
                                }
                                if (y1 >= arrayHeight) {
                                    y1 = y1 - arrayHeight;
                                }
                                if (grid[x1][y1].alive)
                                    c.energy = c.energy + (grid[x1][y1].energyTransferIntent[ex][ey] / c.totalenergyTransferIntent) * grid[x1][y1].energy * transferefficiency;
                            }
                        }
                    }

                }else{
                    //System.out.println("deadcell energy ="+c.energy);
                    double energy = 0;
                    int greatestX = 0;
                    int greatestY = 0;
                    double greatestContribution=0;
                    for (int ex = 0; ex < 3; ex++) {
                        for (int ey = 0; ey < 3; ey++) {
                            if(!(ex==1&&ey==1)) {
                                cell cell1;
                                int x1 = ex + x - 1;
                                int y1 = ey + y - 1;
                                if (x1 < 0) {
                                    x1 = x1 + arrayWidth;
                                }
                                if (x1 >= arrayWidth) {
                                    x1 = x1 - arrayWidth;
                                }
                                if (y1 < 0) {
                                    y1 = y1 + arrayHeight;
                                }
                                if (y1 >= arrayHeight) {
                                    y1 = y1 - arrayHeight;
                                }
                                if (grid[x1][y1].alive) {
                                    double contribution = (grid[x1][y1].energyTransferIntent[ex*-1+2][ey*-1+2] / c.totalenergyTransferIntent) * transferefficiency * grid[x1][y1].energy;
                                    energy = energy + contribution;
                                    if (contribution > greatestContribution) {

                                        greatestX = x1;
                                        greatestY = y1;
                                        greatestContribution = contribution;
                                    }
                                }
                            }
                        }
                    }
                    if(energy>0.1){
                        //System.out.println("newcell");
                        c=grid[greatestX][greatestY];
                        c.energy=energy;
                    }
                }
                newgrid[x][y] = c;
            }
        }
        */
            grid = newgrid;
        }
        Display();
    }

    public cell battleCells(cell def,cell att) {
        if(att.health<0 || att.age>maxage){
            return def;
        }
        if(def.health<0 || def.age>maxage){
            cell c = cell.copy(att,true).mutate();
            c.health = StartingHealth;
            return c;
        }
        cell defender = cell.copy(def,false);
        cell attacker = cell.copy(att,false);
        boolean attackerRun = runCode(attacker,defender);
        boolean defenderRun = runCode(defender,attacker);
        if (attackerRun) {
            if(defenderRun){
                att.health = att.health-0.1;
                defender.health = defender.health+0.1;
                return defender;
            }else{
                att.health = att.health+0.05;
                defender = cell.copy(attacker,true).mutate();
                defender.health = StartingHealth;
                return defender;
            }
        } else {
            att.health = att.health-0.5;
            if(defenderRun) {
                return defender;
            }else{
                defender.health=0;
                return defender;
            }
        }
    }

    public boolean runCode(cell runner,cell opponent){
       boolean runSuccessfully = true;
       int chromosomeIndex = runner.startingChromosome;
       int geneIndex = runner.startingGene;//(int)Math.floor(runner.Code.get(chromosomeIndex).size()*Math.random()*0.99f);


        for(int i = 14; i>0;i--){// puts limit on how many commands can be run


           if(runner.Code.size()<=chromosomeIndex )chromosomeIndex = runner.Code.size()-1;
           if(chromosomeIndex<0)chromosomeIndex=0;
           if(geneIndex >=runner.Code.get(chromosomeIndex).size()) geneIndex = 0;

           if(runner.Code.get(chromosomeIndex).size()<=geneIndex){
               return false;
           }
           command com = runner.Code.get(chromosomeIndex).get(geneIndex);
           if(com.commandID==0){//exit command
               runner.health=runner.health-0.5;
               if(runner.health<0){
                   return false;
               }
           }else
           if(com.commandID==1) {//copy a single gene - 6 params (from self or opponent - chromosome - gene - to self or opponent - chromosome - gene )
               try {// catch exceptions and return false
                   if (com.parameters[0] < 1) {
                       //from self
                       command gene;
                       gene = runner.Code.get((int) Math.floor(com.parameters[1])).get((int) Math.floor(com.parameters[2])).copy();
                       if (com.parameters[3] < 1) {
                           //to self
                           runner.Code.get((int) Math.floor(com.parameters[4])).set((int) Math.floor(com.parameters[5]), gene);
                       } else {
                           // to other
                           opponent.Code.get((int) Math.floor(com.parameters[4])).set((int) Math.floor(com.parameters[5]), gene);
                       }


                   } else {
                       //from other
                       command gene;
                       gene = opponent.Code.get((int) Math.floor(com.parameters[1])).get((int) Math.floor(com.parameters[2])).copy();
                       if (com.parameters[3] < 1) {
                           //to self
                           runner.Code.get((int) Math.floor(com.parameters[4])).set((int) Math.floor(com.parameters[5]), gene);
                       } else {
                           // to other
                           opponent.Code.get((int) Math.floor(com.parameters[4])).set((int) Math.floor(com.parameters[5]), gene);
                       }
                   }
               } catch (Exception e) {
                   //return false;
               }
           }else if(com.commandID==2){ // jump to another location
               try{
                   if(com.parameters[0]<1) {
                       chromosomeIndex = (int)Math.floor( com.parameters[1]);
                       geneIndex = (int)Math.floor( com.parameters[2])-1;
                   }else{
                       chromosomeIndex = (int)Math.floor( com.parameters[1]);
                   }

               } catch (Exception e) {
                   //return false;
               }
           }
           geneIndex++;
       }


       return  runSuccessfully;
    }

    static int DisplayedCellX = 0;
    static int DisplayedCellY = 0;
    static cell displayedCell;
    public void Display() {

        //BufferedImage ig = new BufferedImage(windowWidth, windowHeight,
        //        BufferedImage.TYPE_INT_ARGB_PRE);
        Graphics g = img.getGraphics();

        if(!paused||updateGraphicsFlag) {
            updateGraphicsFlag=false;
            g.setColor(Color.lightGray);
            g.fillRect(0, 0, arrayWidth * scale, windowHeight);
            for (int x = 0; arrayWidth > x; x++
            ) {
                for (int y = 0; arrayHeight > y; y++
                ) {
                    double fr;
                    double fg;
                    double fb;

                    // ----------Unsmoothed display code -------------
                    if (grid[x][y] != null) {
                        ArrayList<ArrayList<command>> code = grid[x][y].Code;
                        if(grid[x][y].health>0) {
                            if (showSelfCopyingCommands) {

                                float quantity = 0;
                                float i = 0;
                                double[] color = grid[x][y].color;
                                fr = color[0];
                                fg = color[1];
                                fb = color[2];
                                for (command c : code.get(0)) {
                                    if (c.commandID == 1) {
                                        if (c.parameters[0] < 1 && c.parameters[3] > 1 && Math.floor(c.parameters[2]) == i && Math.floor(c.parameters[1]) == 0 && (Math.floor(c.parameters[1]) == Math.floor(c.parameters[4])) && (Math.floor(c.parameters[2]) == Math.floor(c.parameters[5])))
                                            quantity++;
                                    }
                                    i++;
                                }
                                g.setColor(new Color(0, (float) fg / 3, (float) fb / 3));
                                g.fillRect(x * scale, y * scale, scale, scale);
                                g.setColor(new Color(Math.min(quantity / 4, 1), 0, 0));
                                g.drawRect(x * scale, y * scale, scale - 1, scale - 1);
                            } else if (showKillCommands) {
                                //if(grid[x][y].health>0) {
                                float quantity = 0;
                                float i = 0;
                                double[] color = grid[x][y].color;
                                fr = color[0];
                                fg = color[1];
                                fb = color[2];
                                for (command c : code.get(0)) {
                                    try {
                                        if (c.commandID == 1 && c.parameters[0] < 1 && Math.floor(c.parameters[3]) > 1 && code.get((int) Math.floor(c.parameters[1])).get((int) Math.floor(c.parameters[2])).commandID == 0) {
                                            // this command inserts a kill code into the opponent
                                            quantity++;
                                        }
                                    } catch (Exception e) {

                                    }

                                    i++;
                                }


                                g.setColor(new Color(0, (float) fg / 3, (float) fb / 3));
                                g.fillRect(x * scale, y * scale, scale, scale);
                                g.setColor(new Color(Math.min(quantity / 4, 1), 0, 0));
                                g.drawRect(x * scale, y * scale, scale - 1, scale - 1);
                            } else {
                                double[] color = grid[x][y].color;
                                fr = color[0];
                                fg = color[1];
                                fb = color[2];
                                g.setColor(new Color((float) fr, (float) fg, (float) fb));
                                g.fillRect(x * scale, y * scale, scale, scale);
                            }
                        }else{
                            g.setColor(Color.darkGray);
                            g.fillRect(x * scale, y * scale, scale, scale);
                        }
                        //}
                    } else {
                        g.setColor(new Color(0.5f, 0f, 0f));
                        g.fillRect(x * scale, y * scale, scale, scale);
                        g.setColor(new Color(1f, 0f, 0f));
                        g.fillRect(x * scale + 1, y * scale + scale / 2, scale - 2, 1);
                    }
                }
            }
            //img = ig;

            //cell displayedCell = grid[DisplayedCellX][DisplayedCellY];
            //g.drawImage(img, 0, 0, null);
        }

        if (updateText) {


            g.setColor(Color.lightGray);
            g.fillRect(arrayWidth * scale, 0, arrayWidth * scale, windowHeight);

            g.setColor(Color.lightGray);
            g.fillRect(arrayWidth * scale, 0, windowWidth - arrayWidth * scale, windowHeight);
            g.setColor(Color.BLACK);
            if (displayedCell != null) {
                g.drawString("Location: " + DisplayedCellX + " - " + DisplayedCellY, scale * arrayWidth + 20, 30);
                g.drawString(displayedCell.toString(), scale * arrayWidth + 20, 50);
                g.drawString("CODE:", scale * arrayWidth + 20, 65);
                g.drawString("Start Position: "+displayedCell.startingChromosome + " - "+displayedCell.startingGene, scale * arrayWidth + 100, 65);
                g.setColor(new Color((float)displayedCell.color[0],(float)displayedCell.color[1],(float)displayedCell.color[2]));
                g.fillRect(scale * arrayWidth + 220,52,500,12);
                g.setColor(Color.BLACK);
                ArrayList<ArrayList<command>> code = displayedCell.Code;
                int offsety = 0;

                for (int i = 0; i < code.size(); i++) {
                    g.drawString("Chromosome " + i, scale * arrayWidth + 2, 80 + offsety * 15);
                    for (int i1 = 0; i1 < code.get(i).size(); i1++) {


                        if (i == displayedCell.startingChromosome && i1 == displayedCell.startingGene) {
                            g.setColor(Color.RED);
                        } else {
                            g.setColor(Color.BLACK);
                        }
                        command c = code.get(i).get(i1);
                        if (c.parameters[0] < 1 && c.parameters[3] > 1 && Math.floor(c.parameters[2]) == i1 && Math.floor(c.parameters[1]) == i && (Math.floor(c.parameters[1]) == Math.floor(c.parameters[4])) && (Math.floor(c.parameters[2]) == Math.floor(c.parameters[5]))){
                            g.setColor(Color.green);
                        }
                        String params = "";
                        int i2 = 0;
                        for (float f : code.get(i).get(i1).parameters) {
                            params = params + " " + i2 + ": " + f;
                            i2++;
                        }

                        g.drawString(i1 + ":  " + code.get(i).get(i1).commandID + " Params: " + params, scale * arrayWidth + 100, 80 + offsety * 15);
                        offsety++;
                    }

                }
                offsety = 0;

                int offsetx = 650;
                for (int i = 0; i < code.size(); i++) {
                    g.drawString("Chromosome " + i, scale * arrayWidth + 2 + offsetx, 80 + offsety * 15);
                    for (int i1 = 0; i1 < code.get(i).size(); i1++) {
                        if (i == displayedCell.startingChromosome && i1 == displayedCell.startingGene) {
                            g.setColor(Color.RED);
                        } else {
                            g.setColor(Color.BLACK);
                        }
                        command c = code.get(i).get(i1);
                        if (c.commandID== 1 && c.parameters[0] < 1 && c.parameters[3] > 1 && Math.floor(c.parameters[2]) == i1 && Math.floor(c.parameters[1]) == i && (Math.floor(c.parameters[1]) == Math.floor(c.parameters[4])) && (Math.floor(c.parameters[2]) == Math.floor(c.parameters[5]))){
                            g.setColor(Color.green);
                        }
                        try {
                            if (c.commandID == 1 && c.parameters[0] < 1 && c.parameters[3] >= 1 && code.get(  (int)Math.floor(c.parameters[1])  ).get(  (int)Math.floor(c.parameters[2])  ).commandID==0   ){
                                // this command inserts a kill code into the opponent
                                g.setColor(new Color(1f,0.2f,0.2f));
                            }
                        }catch(Exception e){

                        }
                        g.drawString(parseCommand(c), scale * arrayWidth + 100 + offsetx, 80 + offsety * 15);
                        //g.drawString(i1+":  "+code.get(i).get(i1).commandID + " Params: " + params, scale * arrayWidth + 100, 80+offsety*15);
                        offsety++;
                    }

                }
            } else {
                g.drawString("Location: " + DisplayedCellX + " - " + DisplayedCellY, scale * arrayWidth + 20, 30);
                g.drawString("Null at time of click", scale * arrayWidth + 20, 50);
            }
            updateText = false;

        }
        label.setIcon(new ImageIcon(img));


        g.dispose();
        repaint();
    }

    public String parseCommand(command com){
        String str = " - ";

        if(com.commandID == 0 ){
            if(com.parameters[0]<0){
                str = "Kill Self";
            }else{
                str = "Kill Self";
            }
        }else if(com.commandID==1) {//copy a single gene - 6 params (from self or opponent - chromosome - gene - to self or opponent - chromosome - gene )

                String fromGene = (int) Math.floor(com.parameters[1]) + " " +(int) Math.floor(com.parameters[2]);
                String toGene = (int) Math.floor(com.parameters[4])+" "+(int) Math.floor(com.parameters[5]);
                if (com.parameters[0] < 1) {
                    //from self

                    if (com.parameters[3] < 1) {
                        //to self
                        str = "Copy gene from self: "+fromGene+" to self at "+toGene;
                    } else {
                        // to other
                        str = "Copy gene from self: "+fromGene+" to opponent at "+toGene;
                    }


                } else {
                    //from other
                    if (com.parameters[3] < 1) {
                        str = "Copy gene from opponent: "+fromGene+" to self at "+toGene;
                        //to self
                    } else {
                        str = "Copy gene from opponent: "+fromGene+" to opponent at "+toGene;
                        // to other
                    }
                }
        }else if(com.commandID==2) { // jump to another location

            if (com.parameters[0] < 1) {
                int chromosomeIndex = (int)Math.floor( com.parameters[1]);
                int geneIndex = (int) Math.floor(com.parameters[2]);
                str = "go to chromosome "+chromosomeIndex+" gene "+geneIndex;
            } else {
                int chromosomeIndex = (int)Math.floor( com.parameters[1]);
                str = "go to chromosome "+chromosomeIndex;
            }
        }
        return str;
    }

    public void PaintText(){
        Graphics g = img.getGraphics();
        g.setColor(Color.lightGray);
        g.fillRect(arrayWidth*scale,0, windowWidth- arrayWidth*scale, windowHeight);
        g.setColor(Color.BLACK);
        if(displayedCell!=null) {
            g.drawString("Location: " + DisplayedCellX + " - " + DisplayedCellY, scale * arrayWidth + 20, 30);
            g.drawString(displayedCell.toString(), scale * arrayWidth + 20, 50);
            g.drawString("CODE:", scale * arrayWidth + 20, 65);

            ArrayList<ArrayList<command>> code = displayedCell.Code;
            int offsety = 0;
            for(int i = 0;i<code.size();i++){
                g.drawString("Chromosome "+i, scale * arrayWidth + 2, 80+offsety*15);
                for(int i1 = 0;i1<code.get(i).size();i1++){
                    if(i==displayedCell.startingChromosome&&i1 == displayedCell.startingGene){
                        g.setColor(Color.RED);
                    }else{
                        g.setColor(Color.BLACK);
                    }
                    String params = "";
                    int i2 = 0;
                    for (float f:code.get(i).get(i1).parameters) {
                        params.concat(" ---"+i2+"): "+f);
                        i2++;
                    }
                    g.drawString(i1+":  "+code.get(i).get(i1).commandID + " Params: " + params, scale * arrayWidth + 100, 80+offsety*15);
                    offsety++;
                }

            }

            offsety = 5;
            for(int i = 0;i<code.size();i++){
                g.drawString("Chromosome "+i, scale * arrayWidth + 2, 80+offsety*15);
                for(int i1 = 0;i1<code.get(i).size();i1++){
                    if(i==displayedCell.startingChromosome&&i1 == displayedCell.startingGene){
                        g.setColor(Color.RED);
                    }else{
                        g.setColor(Color.BLACK);
                    }
                    command com = code.get(i).get(i1);
                    if(com.commandID == 0 ){
                        if(com.parameters[0]<0){
                            g.drawString("Kill Self", scale * arrayWidth + 100, 80+offsety*15);
                        }else{
                            g.drawString("Kill Self", scale * arrayWidth + 100, 80+offsety*15);
                        }
                    }
                    //g.drawString(i1+":  "+code.get(i).get(i1).commandID + " Params: " + params, scale * arrayWidth + 100, 80+offsety*15);
                    offsety++;
                }

            }
        }else{
            g.drawString("Location: " + DisplayedCellX + " - " + DisplayedCellY, scale * arrayWidth + 20, 30);
            g.drawString("Null at time of click", scale * arrayWidth + 20, 50);
        }
        g.dispose();
        repaint();
    }


    @Override
    public void paintComponent(Graphics g) {
        g.drawImage(img, 0, 0, null);
    }

}
